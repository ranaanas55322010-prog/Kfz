/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Pizza, 
  MapPin, 
  Phone, 
  Star, 
  Clock, 
  ChevronRight, 
  X, 
  UtensilsCrossed, 
  ShoppingBag,
  Menu as MenuIcon,
  Navigation,
  CheckCircle2
} from 'lucide-react';

// Configuration & Constants
const PHONE_NUMBER = "03002526410";
const RESTAURANT_NAME = "KFZ PIZZA";
const ADDRESS = "79PG+W2H, Piplan";
const MAPS_URL = `https://www.google.com/maps/search/?api=1&query=KFZ+PIZZA,+Piplan`;

const OVERVIEW_IMAGES = [
  "/images/gjshdKDy/ff.jpg",
  "/images/L4DgJNtX/ff1.jpg",
  "/images/T13wjvVG/ff2.jpg",
  "/images/Jn4mvcGf/ff4.jpg",
  "/images/50N1Tq6Z/ff5.jpg",
  "/images/RFV9yQN2/ff6.jpg",
  "/images/635wgLyP/ff7.jpg"
];

const MENU_IMAGE = "/images/QCZLsQM4/mm1.webp";

const REVIEWS = [
  {
    name: "Shahzain Khan",
    rating: 5,
    text: "Their special sandwich is love! Clean environment and great cutlery.",
    date: "5 months ago",
    spent: "Rs 1–1,000"
  },
  {
    name: "The Londoners Story",
    rating: 1,
    text: "Gave me thin watery diarrhoea, never going back or recommending it to my worst enemies.",
    date: "8 months ago",
    spent: "Rs 500–1,000"
  },
  {
    name: "Muhammad Safwan Karim",
    rating: 1,
    text: "Ordered chicken tikka pizza on delivery but they started ignoring my calls later. Worst customer service.",
    date: "2 years ago",
    tag: "Delivery"
  }
];

export default function App() {
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleOrderSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const name = formData.get('name');
    const phone = formData.get('phone');
    const address = formData.get('address');
    const items = formData.get('items');

    const message = `*New Order from KFZ PIZZA Website*%0A%0A*Name:* ${name}%0A*Phone:* ${phone}%0A*Address:* ${address}%0A*Order:* ${items}`;
    window.open(`https://wa.me/92${PHONE_NUMBER.substring(1)}?text=${message}`, '_blank');
    setIsOrderModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-yellow-400 selection:text-black">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-black/90 backdrop-blur-md py-3 border-b border-yellow-400/20' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2"
          >
            <div className="bg-yellow-400 p-1.5 rounded-lg box-shadow-yellow">
              <Pizza className="text-black w-6 h-6" />
            </div>
            <span className="font-black text-2xl tracking-tighter text-yellow-400">KFZ PIZZA</span>
          </motion.div>
          
          <div className="hidden md:flex items-center gap-8 font-bold text-sm tracking-widest uppercase">
            {['Overview', 'Menu', 'Reviews', 'Location'].map((item) => (
              <a 
                key={item} 
                href={`#${item.toLowerCase()}`} 
                className="hover:text-yellow-400 transition-colors"
              >
                {item}
              </a>
            ))}
          </div>

          <button 
            onClick={() => setIsOrderModalOpen(true)}
            className="bg-yellow-400 text-black px-6 py-2.5 rounded-full font-black text-sm uppercase tracking-tighter hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
          >
            Order Now
            <ShoppingBag className="w-4 h-4" />
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent z-10" />
          <img 
            src={OVERVIEW_IMAGES[0]} 
            alt="Hero Background" 
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover grayscale opacity-40 scale-110"
          />
        </div>

        <div className="relative z-20 max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 bg-yellow-400/10 text-yellow-400 px-4 py-2 rounded-full border border-yellow-400/20 mb-8">
              <Star className="w-4 h-4 fill-yellow-400" />
              <span className="text-xs font-black uppercase tracking-widest">Top Rated in Piplan (3.9/5)</span>
            </div>
            <h1 className="text-6xl md:text-8xl font-black mb-8 leading-[0.9] tracking-tighter">
              PIZZA <br />
              <span className="text-yellow-400">WITHOUT</span> <br />
              LIMITS.
            </h1>
            <p className="text-xl text-zinc-400 max-w-md mb-10 leading-relaxed font-medium">
              Experience the legendary Tikka and Kabab flavors that Piplan craves. Bold, spicy, and always fresh.
            </p>
            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => setIsOrderModalOpen(true)}
                className="bg-yellow-400 text-black px-10 py-5 rounded-2xl font-black text-lg uppercase tracking-tighter hover:bg-yellow-500 transition-colors flex items-center gap-3"
              >
                Start Your Order
                <ChevronRight className="w-6 h-6" />
              </button>
              <a 
                href="#menu"
                className="bg-zinc-900 border border-zinc-800 text-white px-10 py-5 rounded-2xl font-black text-lg uppercase tracking-tighter hover:bg-zinc-800 transition-colors"
              >
                View Menu
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="hidden md:block relative"
          >
            <div className="absolute -inset-4 bg-yellow-400/20 blur-3xl rounded-full" />
            <img 
              src={OVERVIEW_IMAGES[1]} 
              alt="Pizza close up" 
              referrerPolicy="no-referrer"
              className="relative z-10 rounded-3xl border-2 border-yellow-400 shadow-2xl skew-y-3"
            />
          </motion.div>
        </div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce opacity-30">
          <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center pt-2">
            <div className="w-1 h-2 bg-white rounded-full" />
          </div>
        </div>
      </section>

      {/* Stats/Quick Info */}
      <div className="bg-yellow-400 py-6 overflow-hidden border-y-4 border-black">
        <div className="whitespace-nowrap flex gap-12 animate-marquee">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="flex items-center gap-8 font-black text-black text-2xl italic tracking-tighter">
              <span>OPEN UNTIL 12 AM</span>
              <Pizza className="w-8 h-8 fill-black" />
              <span>PRIVATE DINING</span>
              <Pizza className="w-8 h-8 fill-black" />
              <span>BIRTHDAY READY</span>
              <Pizza className="w-8 h-8 fill-black" />
            </div>
          ))}
        </div>
      </div>

      {/* Overview Gallery */}
      <section id="overview" className="py-24 px-6 bg-zinc-950">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <h2 className="text-sm font-black text-yellow-400 uppercase tracking-widest mb-4">The Atmosphere</h2>
            <h3 className="text-5xl font-black tracking-tighter">OUR PIZZERIA</h3>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 auto-rows-[150px] md:auto-rows-[250px]">
            {OVERVIEW_IMAGES.map((img, idx) => (
              <motion.div
                key={idx}
                whileHover={{ y: -10 }}
                className={`rounded-2xl overflow-hidden border border-zinc-900 group relative ${
                  idx === 0 ? 'col-span-2 row-span-2' : 'col-span-1 row-span-1'
                }`}
              >
                <img 
                  src={img} 
                  alt={`Restaurant ${idx}`} 
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                />
                <div className="absolute inset-0 bg-yellow-400/0 group-hover:bg-yellow-400/10 transition-colors pointer-events-none" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section id="menu" className="py-24 px-6 border-t border-zinc-900">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16">
            <div>
              <h2 className="text-sm font-black text-yellow-400 uppercase tracking-widest mb-4">Flavor Lineup</h2>
              <h3 className="text-5xl font-black tracking-tighter leading-none">THE MENU</h3>
            </div>
            <button 
              onClick={() => setIsOrderModalOpen(true)}
              className="bg-yellow-400 text-black px-8 py-4 rounded-xl font-bold uppercase tracking-tighter hover:scale-105 transition-transform"
            >
              Order from this menu
            </button>
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="rounded-[2.5rem] overflow-hidden border-8 border-yellow-400/20 bg-zinc-900 shadow-3xl"
          >
            <img 
              src={MENU_IMAGE} 
              alt="KFZ Pizza Menu" 
              referrerPolicy="no-referrer"
              className="w-full h-auto cursor-zoom-in"
              onClick={() => window.open(MENU_IMAGE, '_blank', 'noopener,noreferrer')}
            />
          </motion.div>
          
          <div className="mt-12 p-8 rounded-3xl bg-zinc-900 border border-zinc-800 grid md:grid-cols-3 gap-8">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-yellow-400/10 rounded-xl">
                <UtensilsCrossed className="text-yellow-400 w-6 h-6" />
              </div>
              <div>
                <p className="font-bold">Pure Desi Spice</p>
                <p className="text-sm text-zinc-500">Traditional Tikka Masala Base</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="p-3 bg-yellow-400/10 rounded-xl">
                <Clock className="text-yellow-400 w-6 h-6" />
              </div>
              <div>
                <p className="font-bold">Fast Turnaround</p>
                <p className="text-sm text-zinc-500">Pick-up in 15-20 Minutes</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="p-3 bg-yellow-400/10 rounded-xl">
                <MapPin className="text-yellow-400 w-6 h-6" />
              </div>
              <div>
                <p className="font-bold">Local Roots</p>
                <p className="text-sm text-zinc-500">Proudly Serving Piplan</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="py-24 px-6 bg-black">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-12 items-start">
            <div className="md:sticky md:top-32">
              <h2 className="text-sm font-black text-yellow-400 uppercase tracking-widest mb-4">Customer Talk</h2>
              <h3 className="text-5xl font-black tracking-tighter mb-8">VOICES OF PIPLAN</h3>
              <div className="bg-zinc-900 p-8 rounded-3xl border border-zinc-800">
                <div className="flex items-center gap-4 mb-4">
                  <div className="text-5xl font-black text-yellow-400">3.9</div>
                  <div className="flex flex-col">
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`w-4 h-4 ${i < 4 ? 'fill-yellow-400' : ''}`} />
                      ))}
                    </div>
                    <span className="text-xs text-zinc-500 font-bold uppercase tracking-widest">56 Google Reviews</span>
                  </div>
                </div>
                <p className="text-sm text-zinc-400 italic">"Recognized for its energetic atmosphere and loyal local base."</p>
              </div>
            </div>

            <div className="md:col-span-2 grid gap-6">
              {REVIEWS.map((review, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="bg-zinc-900 border border-zinc-800 p-8 rounded-3xl hover:border-yellow-400/40 transition-colors"
                >
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <h4 className="font-black text-lg underline decoration-yellow-400/50 underline-offset-4">{review.name}</h4>
                      <div className="flex text-yellow-400 mt-2">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className={`w-3 h-3 ${i < review.rating ? 'fill-yellow-400' : 'text-zinc-700'}`} />
                        ))}
                      </div>
                    </div>
                    <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">{review.date}</span>
                  </div>
                  <p className="text-zinc-300 leading-relaxed font-medium mb-4 italic">"{review.text}"</p>
                  <div className="flex gap-4">
                    {review.tag && <span className="text-[10px] bg-sky-500/10 text-sky-400 px-3 py-1 rounded-full font-black uppercase">{review.tag}</span>}
                    {review.spent && <span className="text-[10px] bg-green-500/10 text-green-400 px-3 py-1 rounded-full font-black uppercase">{review.spent}</span>}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Location Section */}
      <section id="location" className="py-24 px-6 border-y border-zinc-900 bg-zinc-950">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
          <div className="relative rounded-[3rem] overflow-hidden border-4 border-zinc-800 min-h-[400px] md:aspect-square">
            <iframe 
              src="https://maps.google.com/maps?q=KFZ%20PIZZA,%20Piplan&t=&z=15&ie=UTF8&iwloc=&output=embed" 
              width="100%" 
              height="100%" 
              style={{ border: 0, position: 'absolute', inset: 0 }} 
              allowFullScreen 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>

          <div>
            <h2 className="text-sm font-black text-yellow-400 uppercase tracking-widest mb-4">Ready for Visit?</h2>
            <h3 className="text-5xl font-black tracking-tighter mb-10">CONTACT & HOURS</h3>
            
            <div className="grid gap-8">
              <div className="flex gap-6">
                <div className="bg-zinc-900 p-4 rounded-2xl border border-zinc-800">
                  <Phone className="text-yellow-400 w-10 h-10" />
                </div>
                <div>
                  <p className="text-zinc-500 font-bold uppercase text-xs tracking-widest mb-1">Call Us Directly</p>
                  <a href={`tel:${PHONE_NUMBER}`} className="text-3xl font-black hover:text-yellow-400 transition-colors tracking-tight">0300 2526410</a>
                </div>
              </div>

              <div className="flex gap-6">
                <div className="bg-zinc-900 p-4 rounded-2xl border border-zinc-800">
                  <Clock className="text-yellow-400 w-10 h-10" />
                </div>
                <div>
                  <p className="text-zinc-500 font-bold uppercase text-xs tracking-widest mb-1">Standard Hours</p>
                  <p className="text-xl font-bold tracking-tight">Open Daily: <span className="text-yellow-400">12:00 PM – 12:00 AM</span></p>
                </div>
              </div>


            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-24 px-6 border-t border-zinc-900">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-12">
          <div>
            <div className="flex items-center gap-2 mb-6">
              <div className="bg-yellow-400 p-1 rounded-md">
                <Pizza className="text-black w-5 h-5" />
              </div>
              <span className="font-black text-xl tracking-tighter text-yellow-400 uppercase">KFZ PIZZA</span>
            </div>
            <p className="text-zinc-500 text-sm font-medium">© 2026 KFZ PIZZA. All rights reserved. <br />Piplan's Finest Pizza House.</p>
          </div>

          <div className="flex gap-6 items-center">
            <button 
              onClick={() => setIsOrderModalOpen(true)}
              className="bg-yellow-400 text-black p-4 rounded-full font-black uppercase"
            >
              <ShoppingBag className="w-6 h-6" />
            </button>
            <a 
              href={`tel:${PHONE_NUMBER}`}
              className="bg-zinc-900 text-white p-4 rounded-full border border-zinc-800"
            >
              <Phone className="w-6 h-6" />
            </a>
          </div>
        </div>
      </footer>

      {/* Floating Action (Mobile Only) */}
      <div className="fixed bottom-6 right-6 z-50 md:hidden">
        <button 
          onClick={() => setIsOrderModalOpen(true)}
          className="bg-yellow-400 text-black px-6 py-4 rounded-full font-black shadow-2xl flex items-center gap-2 border-2 border-black"
        >
          ORDER NOW
          <ShoppingBag className="w-5 h-5" />
        </button>
      </div>

      {/* Order Modal */}
      <AnimatePresence>
        {isOrderModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOrderModalOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-zinc-950 border border-yellow-400/30 w-full max-w-lg rounded-[2rem] overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="bg-yellow-400 p-8 flex justify-between items-center">
                <div>
                  <h3 className="text-2xl font-black text-black tracking-tight">PLACE ORDER</h3>
                  <p className="text-black/60 text-xs font-bold uppercase tracking-widest">Connect with our staff on WhatsApp</p>
                </div>
                <button 
                  onClick={() => setIsOrderModalOpen(false)}
                  className="bg-black/10 hover:bg-black/20 p-2 rounded-full transition-colors"
                >
                  <X className="w-6 h-6 text-black" />
                </button>
              </div>
              
              <form onSubmit={handleOrderSubmit} className="p-8 space-y-6">
                <div>
                  <label className="block text-[10px] font-black text-yellow-400 uppercase tracking-widest mb-2">Your Full Name</label>
                  <input 
                    required 
                    name="name"
                    type="text" 
                    placeholder="e.g. Shahzain Khan"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 focus:border-yellow-400 outline-none transition-colors font-medium text-white placeholder:text-zinc-600"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-yellow-400 uppercase tracking-widest mb-2">Phone Number</label>
                    <input 
                      required 
                      name="phone"
                      type="tel" 
                      placeholder="03xx xxxxxxxx"
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 focus:border-yellow-400 outline-none transition-colors font-medium text-white placeholder:text-zinc-600"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-yellow-400 uppercase tracking-widest mb-2">Delivery Type</label>
                    <select className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 focus:border-yellow-400 outline-none transition-colors font-medium text-white">
                      <option>Dine-in</option>
                      <option>Delivery</option>
                      <option>Takeaway</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-yellow-400 uppercase tracking-widest mb-2">Residential Address / Table #</label>
                  <input 
                    required 
                    name="address"
                    type="text" 
                    placeholder="Street, Area, Building..."
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 focus:border-yellow-400 outline-none transition-colors font-medium text-white placeholder:text-zinc-600"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-yellow-400 uppercase tracking-widest mb-2">What would you like to have?</label>
                  <textarea 
                    required 
                    name="items"
                    rows={3}
                    placeholder="e.g. Large Tikka Pizza, 2 Special Sandwiches..."
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 focus:border-yellow-400 outline-none transition-colors font-medium text-white placeholder:text-zinc-600 resize-none"
                  />
                  <p className="text-[10px] text-zinc-500 mt-2 font-medium italic">*Check menu section for selection</p>
                </div>

                <button 
                  type="submit"
                  className="w-full bg-yellow-400 text-black py-5 rounded-2xl font-black text-lg uppercase tracking-tighter hover:bg-yellow-500 transition-colors flex items-center justify-center gap-3"
                >
                  Confirm & Message Staff
                  <ChevronRight className="w-6 h-6" />
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 30s linear infinite;
        }
        .box-shadow-yellow {
          box-shadow: 0 0 20px rgba(251, 191, 36, 0.3);
        }
      `}</style>
    </div>
  );
}
